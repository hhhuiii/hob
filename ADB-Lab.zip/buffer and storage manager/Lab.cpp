#include "Lab.h"
#include <time.h>
#define DBFILE "data.dbf"
#define TRACEFILE "data-5w-50w-zipf.txt"
#define CPS  ((clock_t)1000)
clock_t LRU_start, LRU_end; 
double last_time;

void StrToInt(int& int_temp, const string& string_temp) {//page编号字符串转数字操作
	stringstream stream(string_temp);
	stream >> int_temp;
}

vector<string> line_split(const string& rw, const string& id) {//分割页面调用文件中的操作类型与调用页面编号
	vector<string> res;
	if ("" == rw) return res;
	char* strs = new char[rw.length() + 1];
	strcpy(strs, rw.c_str());

	char* d = new char[id.length() + 1];
	strcpy(d, id.c_str());
	char* p = strtok(strs, d);
	while (p) {
		string s = p;
		res.push_back(s);
		p = strtok(NULL, d);
	}
	delete strs;
	return res;
}

void FixNewPage(int nums) {//创建包含nums个页的磁盘文件，并写记录（在实验中需要创建50000个page）
	FILE *wfs = fopen(DBFILE, "wb");
	if (wfs == nullptr) {//未能成功打开数据库文件
		cout << "open or create database file failed" << endl;
		return;
	}
	else {//成功打开数据库文件
		cout << "database file *" << DBFILE << "* open success,writing now......" << endl;
	}
	unsigned page_num = 0;//初始化当前操作的page号
	unsigned page_tstp = 0;//初始化每个page的时戳
	short offset[FRAMESIZE / SINGLESIZE];//表示每一页的第一条记录的起始地址,这一部分单独存储
	int PAGE_HEAD = sizeof(page_tstp) + sizeof(offset);//每一页头部包含16字节的页头信息（包含页号和时戳）
	for (int i = 0; i < FRAMESIZE / SINGLESIZE; i++) {//初始化页偏移量表为每一页第一条记录的起始地址
		offset[i] = PAGE_HEAD + i * SINGLESIZE;
	}
	//对数据库文件进行读写操作
	for (int j = 0; j < nums; j++) {//逐个对page写记录
		//写每一个磁盘page的首部
		page_num = j;
		fwrite(&page_num, sizeof(page_num), 1, wfs); //写页号
		fwrite(&page_tstp, sizeof(page_tstp), 1, wfs); //写页时间戳
		//写入记录
		unsigned int timestamp = j;
		unsigned int length = SINGLESIZE;
		//可以自由分配字段A，B，C，D字段名以及字段长度，字段长度之和保持在510B即可
		char field_A[125];
		char field_B[125];
		char feild_C[124];
		char feild_D[124];
		//每条记录510B，则一个磁盘页去除页头部后恰好可以放入8条记录
		for (int i = 0; i < FRAMESIZE / SINGLESIZE; i++) {
			fwrite(&wfs, sizeof(wfs), 1, wfs);//指向模式的指针 4B
			fwrite(&length, sizeof(length), 1, wfs);//该条记录的长度 4B
			fwrite(&timestamp, sizeof(timestamp), 1, wfs);//该条记录的时戳 4B
			fwrite(&field_A, sizeof(field_A), 1, wfs);//字段A 125B
			fwrite(&field_B, sizeof(field_B), 1, wfs);//字段B 125B
			fwrite(&feild_C, sizeof(feild_C), 1, wfs);//字段C 124B
			fwrite(&feild_D, sizeof(feild_D), 1, wfs);//字段D 124B
		}
	}
	cout << "create *" << nums <<  "* Pages Done." << endl;
	cout << endl;
	fclose(wfs);
}

void DoLRU_with_TraceFile(int page_id, int operation, LRU* LRU_instance) {
	if (operation == 0){//为读操作
		LRU_instance->readData(page_id);
	}
	else if (operation == 1){//为写操作
		LRU_instance->writeData(page_id);
	}
}

int main(){
	cout << "Storage and Buffer Manger Lab" << endl << endl;
	cout << endl;
	cout << "*缓冲区大小设置为:\t" << BUFFERSIZE << endl;//可以更改缓冲区大小进行对比实验
	cout << endl;
	FixNewPage(50000);//调用接口构建50000个page
	string tracefilename = TRACEFILE;
	ifstream traceFile(tracefilename.c_str());
	if (!traceFile){
		cout << "open or create trace << trace file failed" << endl;
		return 1;
	}
	else{
		cout << tracefilename << " 页调用模拟中" << endl << endl;
	}
	char dbfile[] = DBFILE;
	LRU LRU(BUFFERSIZE,dbfile);
	int rw = 0,page_id = 0,request_num = 0;
	string trace;
	LRU_start = clock();//记录调用LRU算法之前的时间
	while (!traceFile.eof()){
		getline(traceFile, trace);
		std::vector<string> res = line_split(trace, ",");
		StrToInt(rw, res[0]);
		StrToInt(page_id, res[1]);
		//循环将读写类型以及请求页号交由LRU算法处理
		DoLRU_with_TraceFile(page_id,rw,&LRU);
		request_num++;
	}
	LRU_end = clock();//记录调用LRU算法完成之后的时间
	LRU.FlushDisk();//调用结束，将脏数据写回磁盘文件
	cout << "*页请求次数:\t" << request_num << endl;//页请求数量
	cout << "*命中次数:\t" << LRU.getcat_number() << endl;//缓冲区命中的页请求数量
	cout << "*磁盘I/O次数:\t" << LRU.getIO_number() << endl;//未命中产生的磁盘I/O数量
	printf("*命中率:\t%.4f%%\n", 100 * LRU.getcat_number() / float(request_num));//命中率
	last_time = ((double)LRU_end - LRU_start) / CLOCKS_PER_SEC;//获取LRU算法的运行时间
	printf("*运行时间:\t%.4fms\n", last_time);
	traceFile.close();
	system("pause");
	return 0;
}  