#include "stdio.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <vector>
#include <unordered_map>
#include <stack>

#define FRAMESIZE 4096//page和frame大小相同
#define BUFFERSIZE 1024//内存缓冲区的大小,可以自行设置
#define SINGLESIZE 510//假定单条记录的大小为510B
#define MAXSIZE FRAMESIZE*BUFFERSIZE

using namespace std;

struct bFrame{//缓冲区frame的定义
	char field[FRAMESIZE];
};

struct Buffer{//缓冲区的定义，包含多个frame
	bFrame frames[BUFFERSIZE];
};

//数据库文件存储管理类
class DSMgr{
public:
	DSMgr(){//无参构造
		this->fstream = nullptr;
	}
	void openFile(char filepath[]){//打开数据库文件
		fstream = fopen(filepath, "rb+");
	}
	void ReadPage(int page_id, int frame_id, Buffer* buffer){//根据page_id和frame_id读入page到frame（没有实际的读实现）
		bFrame bframe;
		fseek(fstream, page_id * FRAMESIZE, SEEK_SET);//将文件指针移动到指定页的起始位置
		buffer->frames[frame_id] = bframe;
	}
	void WritePage(int page_id, int frame_id, Buffer* buffer){//根据frame_id和page_id将frame写入page（没有实际的写实现）
		//bFrame bframe = buffer->frames[frame_id];
		fseek(fstream, page_id * FRAMESIZE, SEEK_SET);//将文件指针移动到指定页的起始位置
	}
private:
	FILE* fstream;
};
//缓冲区控制块BCB类，结构为双向链表
class BufferControlBlocks{
public:
	BufferControlBlocks(){//无参构造初始化
		this->_next = nullptr;
		this->_prev = nullptr;
	}
	BufferControlBlocks(int page_id, int frame_id){//有参构造初始化
		this->page_id = page_id;
		this->frame_id = frame_id;
		this->count = 0;
		this->time = 0;
		this->dirty = 0;
		BufferControlBlocks();
	}
	void del_BCB(){//将此BCB从双向链表中取出
		if (_prev != nullptr){
			this->_prev->_next = this->_next;
		}
		if (_next != nullptr){
			this->_next->_prev = this->_prev;
		}
	}
	void Insert(BufferControlBlocks* node){//将新的BCB链接到此BCB后
		node->_prev = this;
		node->_next = this->_next;
		this->_next->_prev = node;
		this->_next = node;
	}
public://成员变量
	int page_id;//所关联的page
	int frame_id;//所关联的frame
	int ref;//置换参考位
	int count;//用户计数
	int time;//时间戳
	int dirty;//脏位
	BufferControlBlocks* _prev;//指向前一个BCB
	BufferControlBlocks* _next;//指向后一个BCB
};

//LRU缓冲区替换算法类
class LRU{
public:
	LRU(int capacity, char dbfile[]){//有参构造初始化
		head = new BufferControlBlocks;
		tail = new BufferControlBlocks;
		head->_next = tail;
		tail->_prev = head;
		this->size = 0;
		this->capacity = capacity;
		cat_number = IO_number = 0;
		buff = new Buffer;
		StoryMgr.openFile(dbfile);
		for (int i = 0; i < BUFFERSIZE; i++)frameTopage[i] = 0;
		for (int i = 0; i < capacity; i++)frame_ids.push(i);
	}
	int readPage(int page_id) {//读某一页操作（没有读实现，只是维护了LRU链表）返回frame号
	//若不在内存返回-1
		if (hashmap.find(page_id) == hashmap.end()){
			return -1;
		}
		BufferControlBlocks* node = hashmap[page_id];
		node->del_BCB();//将对应的BCB从链表中取出
		head->Insert(node);//取出后将其插入到head后（LRU队列末尾）
		int fid = node->frame_id;
		return fid;
	}
	int read_id(int page_id){//获取page_id对应的frame_id，若page不在内存则返回-1
		if (hashmap.find(page_id) == hashmap.end()){
			return -1;
		}
		BufferControlBlocks* node = hashmap[page_id];
		return node->frame_id;
	}
	int put(int page_id, int frame_id = 0){//将指定page写入LRU对应的缓存页frame中
	//在需要时采取置换操作，置换过程中需要检查脏位若有修改则需写回
	//若page在磁盘中不存在则新建磁盘页
		BufferControlBlocks* node;
		if(page_id == -1){
			cout << "无效的page_id" << endl;
		}
		if (hashmap.find(page_id) == hashmap.end()){
			if (size < capacity){//缓冲区未满，无需替换，为page分配一个frame即可
				frame_id = frame_ids.top();
				frame_ids.pop();
				node = new BufferControlBlocks(page_id, frame_id);
				size++;
				hashmap[page_id] = node;//分配后为该page建立索引指向BCB
			}
			else{//缓冲区已满，需使用LRU算法替换
				node = tail->_prev;
				int i = 0;
				for (;node->ref > 1 || node->count > 1;node = node->_next){
					node->ref = 0; i++;
					if(i == capacity - 1) {
						cout << "需要进行内存写回" << endl; 
					};
					break;
				}
				if (node->dirty != 0){//页被修改过，需将其写回
					node->dirty = 0;
					StoryMgr.WritePage(node->page_id,node->frame_id,buff);
				}
				frame_id = node->frame_id;
				node->del_BCB();
				hashmap.erase(node->page_id);
				node->page_id = page_id;
				node->frame_id = frame_id;
			}
			hashmap[page_id] = node;
			head->Insert(node);
		}
		else {
			node = hashmap[page_id];
			node->del_BCB();
			head->Insert(node);
			frame_id = node->frame_id;
		}
		return frame_id;
	}
	int selectVictim() {//选择替换块
		BufferControlBlocks* node;
		node = tail->_prev;
		int i = 0;
		for(;node->ref > 1 || node->count > 1; node = node->_next){
			node->ref = 0; i++;
			if(i == capacity){
				cout << "需要选择替换块" << endl;
			}
		}
		return node->frame_id;
	}
	void remove(int page_id) {//从内存中替换掉对应的frame
		if(hashmap.find(page_id) == hashmap.end()) {//没有查找到该page_id
			cout << "page_id: " << page_id  << "不存在" << endl;
		}
		BufferControlBlocks* node = hashmap[page_id];
		frame_ids.push(node->frame_id);
		node->del_BCB();
		hashmap.erase(node->page_id);
		size--;
	}
	int AccessPage(int page_id) {//访问某一个page，将其对应的BCB中的dirty位置为1，时间戳加一
		if (hashmap.find(page_id) == hashmap.end()) {
			return -1;
		}
		BufferControlBlocks* node = hashmap[page_id];
		node->dirty = 1;
		node->time += 1;
		node->del_BCB();
		head->Insert(node);
		return node->frame_id;
	}
	int setpin_Count(int page_id) {//设置指定磁盘页的用户数
		if (hashmap.find(page_id) == hashmap.end()) {
			return -1;
		}
		BufferControlBlocks* node = hashmap[page_id];
		node->count += 1;
		node->time += 1;
		node->del_BCB();
		head->Insert(node);
		return node->frame_id;
	}
	void readData(int page_id) {//读指定的页（无实现，用于统计LRU算法命中率和IO次数等数据）
		int frame_id = readPage(page_id);
		if (frame_id == -1){//页不在内存中，需要进行磁盘IO调入该页
			IO_number++;
			frame_id = put(page_id);
			StoryMgr.ReadPage(page_id, frame_id, buff);//读指定的页到指定的frame中
		}
		else{//页在内存中，命中次数加1
			cat_number++;
		}
	}
	void writeData(int page_id) {//写入指定页（无写入实现，用于统计命中率和IO次数等数据）
		int frame_id = readPage(page_id);
		if (frame_id == -1){//写未命中，需要磁盘IO读入该页
			IO_number++;
			frame_id = put(page_id);
			StoryMgr.ReadPage(page_id, frame_id, buff);
		}
		else {//写命中
			cat_number++;
		}
		buff->frames[frame_id].field[1]++;
		BufferControlBlocks* node = hashmap[page_id];
		node->dirty = 1;
	}
	int getIO_number(){//获取算法运行后的磁盘IO次数
		return IO_number;
	}
	int getcat_number(){//获取算法运行后的页命中次数
		return cat_number;
	}
	void FlushDisk(){//将脏数据写回磁盘
		for (BufferControlBlocks* node = head->_next; node != tail; node = node->_next){
			if (node->dirty == 1){
				StoryMgr.WritePage(node->page_id, node->frame_id, buff);
				IO_number++;
				node->dirty = 0;
			}
		}
		delete tail;//head, buff;
	}
private:
	int size;//当前缓冲区大小
	int capacity;//缓冲区的容量上限
	BufferControlBlocks* head, * tail;
	unordered_map<int, BufferControlBlocks*> hashmap;//保存page_id与BCB的映射关系
	int frameTopage[BUFFERSIZE];//保存从frame_id到page_id的映射
	int cat_number;//page访问命中次数，根据LRU算法运行过程记录
	int IO_number;//记录磁盘IO次数，根据LRU算法运行的替换过程记录，并没有真正的磁盘IO操作
	Buffer* buff;
	stack<int> frame_ids;
	DSMgr StoryMgr;
};